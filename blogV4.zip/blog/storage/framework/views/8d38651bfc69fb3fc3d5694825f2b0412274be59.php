<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>
    <hr><h4 class="text-center "><?php echo e(Session::get('message')); ?></h4>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
     
          <!-- /.box -->

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tags</h3>
              <a class="col-sm-offset-5 btn-success btn" href="<?php echo e(route('tags.create')); ?>"> Add New Tag</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>S N</th>
                    <th>Tag Name</th>
                    <th>Tag slug(s)</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td> <?php echo e($loop->index +1); ?> </td>
                      <td><?php echo e($tags->name); ?></td>
                      <td><?php echo e($tags->slug); ?></td>
                      <th><a class="btn btn-success" href="<?php echo e(route('tags.edit',$tags->id)); ?>"><span class="glyphicon glyphicon-edit"></span></a></th>
                      <th>
                        <form id="delete-form-<?php echo e($tags->id); ?>" action="<?php echo e(route('tags.destroy',$tags->id)); ?>" method="post" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                        </form>

                        <a class="btn btn-danger" href="" onclick="if(confirm('Are you want to delete this ?')) {
                          event.preventDefault();
                          document.getElementById('delete-form-<?php echo e($tags->id); ?>').submit();
                        }else{
                          event.preventDefault();
                        } ">
                          <span class="glyphicon glyphicon-trash"></span></a></th>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>S N</th>
                    <th>Tag Name</th>
                    <th>Tag slug(s)</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

 <?php $__env->startSection('footer'); ?>
 <script type="text/javascript" src="<?php echo e(asset('admin\bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('admin\bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin\includes\app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>