<?php $__env->startSection('main-content'); ?>
    <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Text Editors
        <small>Advanced form element</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Editors</li>
      </ol>
    </section>
      <!-- general form elements -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Title</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(route('tags.update',$tags->id)); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

              <div class="box-body">
                <div class="col-lg-offset-3 col-lg-6">
                    <div class="form-group">
                        <label for="Name">Tag Title</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($tags->name); ?>">
                    </div>
        
                    <div class="form-group">
                        <label for="slug">Tag Slug</label>
                        <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($tags->slug); ?>">
                    </div>

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                      <a type="button" href='<?php echo e(route('tags.index')); ?> ' class="btn btn-warning">Back</a>
                    </div>
                </div>
              </div>
            </form>
      </div>
          <!-- /.box -->
    <!-- Main content -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>