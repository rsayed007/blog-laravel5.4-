<!DOCTYPE html>
<html lang="en">

  <head>

 <?php echo $__env->make('user.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <?php echo $__env->make('user.includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </nav>

    <!-- Page Header -->
      <?php echo $__env->make('user.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main Content -->
        <?php $__env->startSection('mainContent'); ?>
          <?php echo $__env->yieldSection(); ?>
        <?php $__env->startSection('postContent'); ?>
          <?php echo $__env->yieldSection(); ?>

    <hr>

    <!-- Footer -->
    <footer>
      <?php echo $__env->make('user.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(asset('user/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php echo e(asset('user/js/clean-blog.min.js')); ?>"></script>

  </body>

</html>
