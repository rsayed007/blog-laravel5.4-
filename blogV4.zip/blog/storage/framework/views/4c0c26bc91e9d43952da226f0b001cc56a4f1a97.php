<?php $__env->startSection('bg-img',Storage::disk('local')->url($slug->image)); ?>
<?php $__env->startSection('post-title',$slug->title); ?>
<?php $__env->startSection('post-sub-title',$slug->subtitle); ?>

<?php $__env->startSection('postContent'); ?>
    <!-- Post Content -->
    <article>
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
              <small style="margin-right: 40% "> <b> Created at </b><span class=""><?php echo e($slug->created_at->diffForHumans()); ?></span> </small>
              <?php $__currentLoopData = $slug->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <small class="col-sm-offset-8 col-sm-1" >
                  <a href=""><?php echo e($categories->name); ?></a>
                </small>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php echo htmlspecialchars_decode($slug->body); ?>

                <hr>
              <h3>Tags</h3>
            <!-- Tag cloude -->
              <?php $__currentLoopData = $slug->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href=""> <small class="" style="border: 1px solid gray; border-radius: 5px; margin: 3px;padding: 5px 20px;" >
                  <?php echo e($categories->name); ?>

                </small> </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>