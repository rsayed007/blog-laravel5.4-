<?php $__env->startSection('bg-img', asset('user/img/contact-bg.jpg') ); ?>
<?php $__env->startSection('post-title',"Register Here"); ?>
<?php $__env->startSection('post-sub-title',''); ?>

<?php $__env->startSection('postContent'); ?>
    <!-- Post Content -->
    <article>
        <div class="container">
            <div class="row">
               You are logged in!
            </div>
        </div>
      </article>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>