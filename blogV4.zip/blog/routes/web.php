<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// route for user part //
Route::group(['namespace'=>'user'],function(){

    Route::get('/','homeController@index' );
    //post routes
    Route::get('/post/{slug}','postController@post');
    //tag routes
    Route::get('/post/tags', 'homeController@tags');
    //category routes
    Route::get('/post/category/{category}', 'homeController@category')->name('category');


});

// route for user part //



// route for admin part //

Route::group(['namespace'=>'admin'],function(){

    Route::get('/admin/home','homeController@home')->name('admin.home');
    //user routes
    Route::resource('/admin/user','userController');
    //post routes
    Route::resource('/admin/post','postController');
    //tags routes
    Route::resource('/admin/tags','tagsController');
    //category routes
    Route::resource('/admin/category','categoryController');

    //Admin auth Routes
    Route::get('admin-login', 'Auth\LoginController@showLoginForm')->name('admin.login');
    Route::post('admin-login', 'Auth\LoginController@login');
});


// route for admin part //




Auth::routes();



















// Route::get('/admin/post', function(){
//     return view('admin.post.post');
// });

// Route::get('/admin/tags', function(){
//     return view('admin.tags.tags');
// });

// Route::get('/admin/category', function(){
//     return view('admin.category.category');
// });

Route::get('/home', 'HomeController@index')->name('home');
