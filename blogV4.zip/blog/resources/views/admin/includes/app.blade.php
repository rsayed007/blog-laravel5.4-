<!DOCTYPE html>
<html lang="en">
<head>
    @include('admin.includes.head')
</head>

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        @include('admin.includes.header')
        @include('admin.includes.sidebar')


        @section('main-content')
            @show

        @include('admin.includes.footer')
    </div>
</body>
</html>