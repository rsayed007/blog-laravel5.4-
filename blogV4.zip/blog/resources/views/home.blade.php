

@extends('user.app')
@section('bg-img', asset('user/img/contact-bg.jpg') )
@section('post-title',"Register Here")
@section('post-sub-title','')

@section('postContent')
    <!-- Post Content -->
    <article>
        <div class="container">
            <div class="row">
               You are logged in!
            </div>
        </div>
      </article>
@endsection




