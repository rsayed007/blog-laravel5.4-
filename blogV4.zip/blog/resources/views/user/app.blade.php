<!DOCTYPE html>
<html lang="en">

  <head>

 @include('user.includes.head')

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      @include('user.includes.nav')
    </nav>

    <!-- Page Header -->
      @include('user.includes.header')

    <!-- Main Content -->
        @section('mainContent')
          @show
        @section('postContent')
          @show

    <hr>

    <!-- Footer -->
    <footer>
      @include('user.includes.footer')
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="{{ asset('user/vendor/jquery/jquery.min.js')}}"></script>
    <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

    <!-- Custom scripts for this template -->
    <script src="{{ asset('user/js/clean-blog.min.js')}}"></script>

  </body>

</html>
