@extends('user.app')
@section('bg-img',Storage::disk('local')->url($slug->image))
@section('post-title',$slug->title)
@section('post-sub-title',$slug->subtitle)

@section('postContent')
    <!-- Post Content -->
    <article>
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
              <small style="margin-right: 40% "> <b> Created at </b><span class="">{{ $slug->created_at->diffForHumans() }}</span> </small>
              @foreach ($slug->category as $categories)

                <small class="col-sm-offset-8 col-sm-1" >
                  <a href="">{{ $categories->name }}</a>
                </small>
              @endforeach

              {!! htmlspecialchars_decode($slug->body) !!}
                <hr>
              <h3>Tags</h3>
            <!-- Tag cloude -->
              @foreach ($slug->category as $categories)
                <a href=""> <small class="" style="border: 1px solid gray; border-radius: 5px; margin: 3px;padding: 5px 20px;" >
                  {{ $categories->name }}
                </small> </a>
              @endforeach
            </div>
          </div>
        </div>
      </article>
@endsection