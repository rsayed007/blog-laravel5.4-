<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\user\post;

class postController extends Controller
{
    public function post(post $slug)
    {
        return view('user.content.post.post',compact('slug'));
    }
}
