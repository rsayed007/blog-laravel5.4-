<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\user\post;

class homeController extends Controller
{
    public function index()
    {
    	$posts = post::where('status',1)->paginate(5);
        return view('user.content.homeContent', compact('posts'));
    }
}
