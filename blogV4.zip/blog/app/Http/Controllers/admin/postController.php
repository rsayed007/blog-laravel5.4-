<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\user\post;
use App\Model\user\tags;
use App\Model\user\category;

class postController extends Controller
{
            /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $posts = post::all();
       return view('admin.post.show', compact('posts'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tags       = tags::all();
        $category   = category::all();
        return view('admin.post.create',compact('tags','category'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'     =>'required',
            'subtitle'  =>'required',
            'slug'      =>'required',
            'body'      =>'required',

        ]);
         if ($request->hasFile('image')) {
            $request->image->store('public');
        }


        $post = new post;
        $post->image    =  $request->image->store('public');
        $post->title    = $request->title;
        $post->subtitle = $request->subtitle;
        $post->slug     = $request->slug;
        $post->status     = $request->status;
        $post->body     = $request->body;
        $post->save();

        $post->tags()->sync($request->tags);
        $post->category()->sync($request->category);

        return redirect(route('post.index'))->with('message','Post save successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $posts = post::with('tags','category')->where('id',$id)->first();
        $tags       = tags::all();
        $category   = category::all();
        return view('admin.post.edit',compact('tags','category','posts'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title'     =>'required',
            'subtitle'  =>'required',
            'slug'      =>'required',
            'body'      =>'required',
            'image'     =>'required',

        ]);
        if ($request->hasFile('image')) {
            $postImage = $request->image->store('public');
        }

        $post = post::find($id);
        $post->image    = $postImage;
        $post->title    = $request->title;
        $post->subtitle = $request->subtitle;
        $post->slug     = $request->slug;
        $post->body     = $request->body;
        $post->status   = $request->status;

        $post->tags()->sync($request->tags);
        $post->category()->sync($request->category);
        $post->save();

        return redirect(route('post.index'))->with('message','Post update successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        post::where('id',$id)->delete();
        return redirect()->back()->with('message','post Deleted successfully');
    }
}
