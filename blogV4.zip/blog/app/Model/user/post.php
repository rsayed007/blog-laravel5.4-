<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class post extends Model
{
    public function tags()
    {
    	return $this->belongsToMany('App\Model\user\tags','post_tags')->withTimestamps();
    }

    public function category()
    {
    	return $this->belongsToMany('App\Model\user\category','category_posts')->withTimestamps();
    }
    
    public function getRouteKeyName() /*function name is defoult for using route name */
    {
    	return 'slug';
    }
}
